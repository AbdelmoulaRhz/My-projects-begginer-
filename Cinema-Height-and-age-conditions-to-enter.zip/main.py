print("Welcome to the cinema \n")

height = int(input("What is your height in Cm ? \n"))

if height >= 140:
  print("\n You can Access after checking age and the amount to pay \n")
  age = int(input("\n What is your age?\n"))
  if age < 12:
    print("\n you must pay 5 USD \n")
  elif age <=17:
    print("\n you must pay 7 USD \n")
  else:
    print("\n You must pay 10 USD \n")
else:
  print("You cannot enter you are under the height fixed to enter the cinema")

print("\n Thank you for your cooperation")