# This is Bill Tip Calculator
print("Welcome to our TIP CALCULATOR!\n")

# Total amount of the Bill 
bill = float(input("what is the total amount of the bill? \n"))

# Here you can change the Tip amount to Fload instead of variable 
tip = int(input("How much do you like give as a Tip ? 5, 8, 10 ?\n"))

# How many people you are in the table it must be an integer
people = int(input("How many people you are in this place to split the bill ? \n"))

bill_include_tip = tip / 100 * bill + bill

bill_per_person = bill / people

Final_Amount = round(bill_per_person, 2)

print(f"Each person should pay: {Final_Amount}  USD\n")

print("Thank you")