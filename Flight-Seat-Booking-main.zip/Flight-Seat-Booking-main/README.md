###Project: Flight Booking

It's a FLight seat booking platform
The Origin is Bangkok-Thailand. You can select desitnation & date flight

1.selct destination, it will show ticket price (USD) per seat in the bottom summary line.

2.select the flight date

3.select seat in the plane map

-the seat which Unavailable is display on red color. => block to select

-the seat which available is display on gray color.

when you click seat it will change from gray to green.

the number of selected seat & total price will show in the bottom summary line.
